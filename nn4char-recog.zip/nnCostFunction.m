function [J grad] = nnCostFunction(nn_params, ...
                                   input_layer_size, ...
                                   hidden_layer_size, ...
                                   num_labels, ...
                                   X, y, lambda)
%NNCOSTFUNCTION Implements the neural network cost function for a two layer
%neural network which performs classification
%   [J grad] = NNCOSTFUNCTON(nn_params, hidden_layer_size, num_labels, ...
%   X, y, lambda) computes the cost and gradient of the neural network. The
%   parameters for the neural network are "unrolled" into the vector
%   nn_params and need to be converted back into the weight matrices. 
% 
%   The returned parameter grad should be a "unrolled" vector of the
%   partial derivatives of the neural network.
%

% Reshape nn_params back into the parameters Theta1 and Theta2, the weight matrices
% for our 2 layer neural network
Theta1 = reshape(nn_params(1:hidden_layer_size * (input_layer_size + 1)), ...
                 hidden_layer_size, (input_layer_size + 1));

Theta2 = reshape(nn_params((1 + (hidden_layer_size * (input_layer_size + 1))):end), ...
                 num_labels, (hidden_layer_size + 1));

% Setup some useful variables
m = size(X, 1);
         
% You need to return the following variables correctly 
J = 0;
Theta1_grad = zeros(size(Theta1));
Theta2_grad = zeros(size(Theta2));

% ====================== YOUR CODE HERE ======================
% Instructions: You should complete the code by working through the
%               following parts.
%
% Part 1: Feedforward the neural network and return the cost in the
%         variable J. After implementing Part 1, you can verify that your
%         cost function computation is correct by verifying the cost
%         computed in ex4.m
%
% Part 2: Implement the backpropagation algorithm to compute the gradients
%         Theta1_grad and Theta2_grad. You should return the partial derivatives of
%         the cost function with respect to Theta1 and Theta2 in Theta1_grad and
%         Theta2_grad, respectively. After implementing Part 2, you can check
%         that your implementation is correct by running checkNNGradients
%
%         Note: The vector y passed into the function is a vector of labels
%               containing values from 1..K. You need to map this vector into a 
%               binary vector of 1's and 0's to be used with the neural network
%               cost function.
%
%         Hint: We recommend implementing backpropagation using a for-loop
%               over the training examples if you are implementing it for the 
%               first time.
%
% Part 3: Implement regularization with the cost function and gradients.
%
%         Hint: You can implement this around the code for
%               backpropagation. That is, you can compute the gradients for
%               the regularization separately and then add them to Theta1_grad
%               and Theta2_grad from Part 2.
%

% ==========================Solution for Part - 1==========================

X = [ones(m,1), X];     % This is to add column of 1's in the X-matrix.

%size(X)

a1 = X;

size(Theta1_grad)
size(Theta2_grad)

% =======This will calculate hidden layer values=====

z2 = a1*Theta1';        % This is correct.

a2 = sigmoid(z2);

%size(a2)

a2 = [ones(m,1), a2];   % This is correct.
%size(a2)

% ======= step for the output layer =======

z3 = a2*Theta2';

a3 = sigmoid(z3);

h = a3;

% =========================================================================
% ==============The below code converts y into the a matrix form ==========

h_rows = size(h,2);

y = [zeros(m,h_rows-1), y];        % This will add 9 columns of 0's

for i=1:m
    temp = y(i,h_rows);
    y(i,h_rows) = 0;
    y(i,temp) = 1;
end

% ========for part - 1 we need to convert y and h into vector form ========
% And then calculate the cost.
% Try to understand this problem carefully by understanding the matrix
% multiplication and then only you will be able to understand what really
% is happening. This is vectroization at its best as no for-loops have been
% used for the implementation.

% ====================section of part - 3 ========================

%big_delta1 = zeros(401,25);

%big_delta2 = zeros(26,10);

delta3 = a3 - y;       % #####################################

%size(delta3)           % # 5000 X 10 - matrix

%size(y)                % # 5000 X 10 - matrix

new_Theta2 = Theta2(:,2:end);

%size(new_Theta2)       % # 10 X 25 - matrix

% ================================================================

y = y';

y_vec = y(:);

%size(y_vec)     % 50,000X1 matrix

h = h';

h_vec = h(:);

h_vec = h_vec';

%size(h_vec)     % 1X50,000 matrix

%size(y)
%disp(y(1:2000,1:10))
% =========================================================================
% =============== The below code will now compute the cost ================
% This is the highly vectorized form of the code. To understand this, you
% first need to understand what really needs to be computed and how
% matrices should be taken and arranged to achieve the results.

err1_nr = log(h_vec)*y_vec;
err2_nr = log(1-h_vec)*(1-y_vec);

J = (-err1_nr-err2_nr)/m;
% =========================================================================
% ==========================Solution for Part - 2==========================
% =====Regularized cost function=====

const = lambda/(2*m);

err1_r = sum(sum(Theta1(:,2:end).*Theta1(:,2:end)));
disp(err1_r);
err2_r = sum(sum(Theta2(:,2:end).*Theta2(:,2:end)));

error_r = err1_r + err2_r;

J = J + (const*error_r);        % This line will take the previous J to output new J.

% =========================================================================
% ==========================Solution for Part - 3==========================
% Back propagation algorithm
% An important point to remember in implementing this is that dimensions of
% Theta1_grad and Theta1 will be same so you don't need to exclude the bias
% unit while calculating Theta1_grad and Theta2_grad (or big_delta1 and 
% big_delta2)

g_derivative_z2 = sigmoidGradient(z2);

%size(g_derivative_z2)          % # 5000 X 25 - matrix

delta2 = (delta3*new_Theta2).*(g_derivative_z2);

%size(delta2)                   % # 5000 X 25 - matrix

%new_a1 = a1(:,2:end);          % No need for this

%size(new_a1)                   % # 5000 X 400 - matrix

%size((new_a1)'*(delta2))       % This is to check

%big_delta1 = (new_a1)'*(delta2);       % This is wrong

big_delta1 = (a1'*delta2)';

%size(big_delta1)               % # 25 X 401 - matrix

%new_a2 = a2(:,2:end);          % No need for this

%size(new_a2)                   % # 5000 X 25 - matrix

big_delta2 = (a2'*delta3)';

%size(big_delta2)               % # 10 X 26 - matrix

%big_delta2 = big_delta2 + (new_a2')*(delta3);  % This is wrong

% -------------------------------------------------------------

Theta1_grad_nr = big_delta1/m;     % # 25 X 401 matrix
Theta2_grad_nr = big_delta2/m;     % # 10 X 26 matrix

% ==================== Adding the regularization terms ====================

Theta1_grad(:,1) = Theta1_grad_nr(:,1);
Theta1_grad(:,2:end) = Theta1_grad_nr(:,2:end) + ((2*const)*Theta1(:,2:end));

Theta2_grad(:,1) = Theta2_grad_nr(:,1);
Theta2_grad(:,2:end)= Theta2_grad_nr(:,2:end) + ((2*const)*Theta2(:,2:end));

% =========================================================================

% Unroll gradients
grad = [Theta1_grad(:) ; Theta2_grad(:)];


end
